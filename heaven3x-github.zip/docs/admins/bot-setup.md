# Bot Setup

Required permissions and channels.