# Wipe Day Runbook

Automated wipe steps.