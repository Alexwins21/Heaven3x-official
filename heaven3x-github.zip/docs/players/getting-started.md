# Getting Started

Use `/link` to link your account.