# Shop

Use `/buy` or the website.