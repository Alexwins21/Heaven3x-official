# Admin Walkthrough Script

Setup → Shop → Wipe → Incidents