# Player Walkthrough Script

Intro → Linking → Shop → Security